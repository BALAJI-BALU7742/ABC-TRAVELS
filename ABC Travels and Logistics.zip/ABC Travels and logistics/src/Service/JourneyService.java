package Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;
import com.DataBaseUtil;

public class JourneyService {

    public void planJourney() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter source: ");
        String source = scanner.nextLine();
        System.out.print("Enter destination: ");
        String destination = scanner.nextLine();
        System.out.print("Enter journey date (YYYY-MM-DD): ");
        LocalDate journeyDate = LocalDate.parse(scanner.nextLine());

        String sql = "SELECT * FROM routes WHERE source = ? AND destination = ? AND journey_date = ?";
        try (Connection conn = DataBaseUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, source);
            pstmt.setString(2, destination);
            pstmt.setDate(3, java.sql.Date.valueOf(journeyDate));
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                double fare = rs.getDouble("ticket_price_per_passenger");
                System.out.println("Journey planned from " + source + " to " + destination + " on " + journeyDate);
                System.out.println("Total fare: " + fare);
            } else {
                System.out.println("No routes available.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void rescheduleJourney() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter booking ID: ");
        int bookingId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter new journey date (YYYY-MM-DD): ");
        LocalDate newDate = LocalDate.parse(scanner.nextLine());

        String sql = "UPDATE bookings SET journey_date = ? WHERE booking_id = ?";
        try (Connection conn = DataBaseUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDate(1, java.sql.Date.valueOf(newDate));
            pstmt.setInt(2, bookingId);
            pstmt.executeUpdate();
            System.out.println("Journey rescheduled.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
