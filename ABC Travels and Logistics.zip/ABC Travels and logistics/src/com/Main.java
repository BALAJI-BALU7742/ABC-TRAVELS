package com;

import Service.UserService;
import Service.JourneyService;

import java.util.Scanner;

public class Main {

    private static UserService userService = new UserService();
    private static JourneyService journeyService = new JourneyService();

    public static void main(String[] args) {
    	 System.out.println("ABC TRAVELS");
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\nMenu:");
            System.out.println("1. Register new admin");
            System.out.println("2. Login");
            System.out.println("3. Plan Journey");
            System.out.println("4. Reschedule Journey");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    userService.registerNewAdmin();
                    break;
                case 2:
                    userService.login();
                    break;
                case 3:
                    journeyService.planJourney();
                    break;
                case 4:
                    journeyService.rescheduleJourney();
                    break;
                case 5:
                    running = false;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }

        scanner.close();
    }
}
